<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="footer, contact, form, icons" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Explore Bangladesh</title>

    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="ex_css/nav.css">
    <link href="https://fonts.googleapis.com/css?family=Julee" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="ex_css/gallery.css">
    <link href="https://fonts.googleapis.com/css?family=Architects+Daughter" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="ex_css/footer-distributed-with-contact-form.css">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->



  
  </head>
  <body>
    <?php require 'navbar.php'; ?>

    <!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
    <li><img src="data1/images/saj.jpg" alt="Sajek Valley" title="Sajek Valley" id="wows1_0"/></li>
    <li><img src="data1/images/rat.jpg" alt="Ratargul" title="Ratargul" id="wows1_1"/></li>
    <li><img src="data1/images/kua.jpg" alt="Kuakata" title="Kuakata" id="wows1_2"/></li>
    <li><img src="data1/images/ra.jpg" alt="Rangamati" title="Rangamati" id="wows1_3"/></li>
    <li><a href="http://wowslider.com"><img src="data1/images/ti.jpg" alt="wowslideshow" title="The Sundarbans" id="wows1_4"/></a></li>
    <li><img src="data1/images/cx1.jpg" alt="Cox's Bazar" title="Cox's Bazar" id="wows1_5"/></li>
  </ul></div>
  <div class="ws_bullets"><div>
    <a href="description.php?id=1" title="nilachol"><span><img src="data1/tooltips/saj.jpg" alt="nilachol"/>1</span></a>
    <a href="description.php?id=2" title="Ratargul"><span><img src="data1/tooltips/rat.jpg" alt="Ratargul"/>2</span></a>
    <a href="description.php?id=3" title="Kuakata"><span><img src="data1/tooltips/kua.jpg" alt="Kuakata"/>3</span></a>
    <a href="description.php?id=4" title="Rangamati"><span><img src="data1/tooltips/ra.jpg" alt="Rangamati"/>4</span></a>
    <a href="description.php?id=5" title="Royal Bengal Tiger"><span><img src="data1/tooltips/ti.jpg" alt="Royal Bengal Tiger"/>5</span></a>
    <a href="description.php?id=6" title="Cox's Bazar"><span><img src="data1/tooltips/cx1.jpg" alt="Cox's Bazar"/>6</span></a>
  
<div class="ws_shadow"></div>
</div>  
</div>
</div>
<div class="container-fluid" id="f1">
<h1  class="image_heading"><b class="img_heading">Popular Places to Visit in Bangladesh</b></h1>
<p class="image_heading2"><b>Find out more about these popular Bangladeshi destinations</b></p>
<div class="row">
<!--1st row-->
  <div class="col-md-4">
    
    <div class="container1">
      <a href="description.php?id=1"><img src="img/nilachol.jpg" alt="Avatar" class="image" style="width:100%"></a>
          <div class="middle">
            <div class="text">Nil Achol</div>
          </div>
    </div>

  </div>

  <div class="col-md-4">
    <div class="container1">
       <a href="description.php?id=2"><img src="img/rat.jpg" alt="Avatar" class="image" style="width:100%"></a>
          <div class="middle">
              <div class="text">Ratargul</div>
          </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="container1">
      <a href="description.php?id=3"><img src="img/panthu.jpg" alt="Avatar" class="image" style="width:100%"></a>
        <div class="middle">
          <div class="text">Bichanakandi</div>
        </div>
    </div>
  </div>
<!-- 1st end -->
<!-- 2nd row -->
<div class="col-md-4">
    
    <div class="container1">
      <a href="description.php?id=4"><img src="img/sundarban.jpg" alt="Avatar" class="image" style="width:100%"></a>
          <div class="middle">
            <div class="text">Sundarban</div>
          </div>
    </div>

  </div>

  <div class="col-md-4">
    <div class="container1">
       <a href="description.php?id=5"><img src="img/sain_martin.jpg" alt="Avatar" class="image" style="width:100%"></a>
          <div class="middle">
              <div class="text">Saint Martin Island</div>
          </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="container1">
      <a href="description.php?id=6"><img src="img/kella.jpg" alt="Avatar" class="image" style="width:100%"></a>
        <div class="middle">
          <div class="text">Heritage Places</div>
        </div>
    </div>
  </div>
<!--2nd row end -->

</div>

<!-- to do start -->

<h1 id="f2" class="image_heading"><b class="img_heading">Specials in Banglasesh</b></h1>
<p class="image_heading2"><b>Explore BD's aquatic and coastal experiences, unique nature, wildlife and food </b></p>
<div class="row">
<!--1st row-->
  <div class="col-md-4">
    
    <div class="container1">
      <img src="img/Tant-saree-making.jpg" alt="Avatar" class="image" style="width:100%">
          <div class="middle">
            <div class="text">Bangladeshi men sometimes wear kurta or panjabi on religious and cultural occasions. Bangladeshi men wear lungi as casual wear (in rural areas) and shirt-pant or suits on formal occasions. Sharee is the main and traditional dress of Bangladeshi women also and some young female also wear salwar kameez</div>
          </div>
    </div>

  </div>

  <div class="col-md-4">
    <div class="container1">
       <img src="img/p037lw3g.jpg" alt="Avatar" class="image" style="width:100%">
          <div class="middle">
              <div class="text">Bangladesh has more than 700 rivers, 8000km of navigable waterways and possibly more types of boats than any other country. Taking a river trip is a quintessential Bangladesh experience, and we recommend you do it as often as you can, from hand-poled river ferries </div>
          </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="container1">
      <img src="img/DSC_0035.JPG" alt="Avatar" class="image" style="width:100%">
        <div class="middle">
          <div class="text">Bangladesh is a land of sweets. There are many kinds of sweets (in Bangla called ‘misti) in its 64 districts. The sweets outside of its capital city Dhaka are even more famous. It is a part of any celebration be it wedding, birthday, exam results, getting a new job, big improvement in any business, birth of a child etc.</div>
        </div>
    </div>
  </div>
<!-- 1st end -->
<!-- 2nd row -->
<div class="col-md-4">
    
    <div class="container1">
      <img src="img/National-Fish-of-Bangladesh.jpeg" alt="Avatar" class="image" style="width:100%">
          <div class="middle">
            <div class="text">Bangladesh is a country with hundreds of rivers and ponds and is notable for being a fish-loving nation, acquiring the name "Machh-e Bhat-e Bangali" which means, "Bengali by fish and rice". Ilish is the national fish of the country where it contributes 13% of country's total fish production.</div>
          </div>
    </div>

  </div>

  <div class="col-md-4">
    <div class="container1">
       <img src="img/16-03-16-Bangabandhu-Sheikh-Mujibur-Rahman-Birth-Anniversary-1.jpg" alt="Avatar" class="image" style="width:100%">
          <div class="middle">
              <div class="text">Sheikh Mujibur Rahman was the founding leader of Bangladesh. He served twice as the country's President and was its strongman premier between 1972 and 1975. Rahman was the leader of the Awami League. He is popularly known as the Bangabandhu (Friend of Bengal).</div>
          </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="container1">
      <img src="img/bangla-new-year.jpg" alt="Avatar" class="image" style="width:100%">
        <div class="middle">
          <div class="text">Pahela Baishakh or Bengali New Year , also called Pohela Boishakh, is the traditional new year day of the Bengali people. It is celebrated on 14 April as a national holiday in Bangladesh, and on 14 or 15 April in the Indian states of West Bengal and Tripura and elsewhere by people of Bengali heritage, irrespective of their religious faith</div>
        </div>
    </div>
  </div>
<!--2nd row end -->

</div>
<div class="col-md-offset-1 col-md-10 edit">
   <h3 class="image_heading"><b>Beautiful Bangladesh at a Glance</b></h3>
      <div class="embed-responsive embed-responsive-16by9 edit_video">
        <iframe class="embed-responsive-item"  src="https://www.youtube.com/embed/E2_iSXGv0Ww"></iframe>
      </div>
  </div>
    
<!-- to do end -->

<h1 id="f3" class="image_heading"><b>INFORMATION TO HELP YOU PLAN YOUR TRIP</b></h1>

<div class="row">
<!--1st row-->
  <div class="col-md-offset-1 col-md-3 img_1">
    <h4 class="image_heading"><b class="img_heading">VISA INFORMATION</b></h4>
    <div class="container1">
      <a href="https://www.visa.gov.bd/" target="_blank"><img src="img/visa.jpg" alt="Avatar" class="image" style="width:100%"></a>
          
    </div>

  </div>

  <div class="col-md-3 img_2">
  <h4 class="image_heading"><b class="img_heading">SUGGESTED PLAN</b></h4>
    <div class="container1">
       <a href=""><img src="img/plan.gif" alt="Avatar" class="image" style="width:100%"></a>
          
    </div>
  </div>

  <div class="col-md-3 img_3">
  <h4 class="image_heading"><b class="img_heading">WEATHER IN BANGLADESH</b></h4>
    <div class="container1">
      <a href="http://bmd.gov.bd/?/home/" target="_blank"><img src="img/weather.png" alt="Avatar" class="image" style="width:100%"></a>
        
    </div>
  </div>



<!-- The content of your page would go here. -->

    <?php require 'footer.php'; ?>

</div>

<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>