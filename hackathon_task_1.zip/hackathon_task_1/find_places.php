<?php 
require 'connection.php';
//$pulock=$user->getallPlace();
//var_dump($pulock);

if(!empty(isset($_POST['submit']))){

    $place_type=$_POST['place_type'][0];
   $place_name=$_POST['place_name'][0];
    $place_amount=$_POST['place_amount'][0];


	 
    
	$query = $con->prepare("SELECT * FROM `places_table` WHERE `place_type` like '%$place_type%' and `place_name` like '%$place_name%' and `place_amount` like '%$place_amount%'");
   $query->execute();
   $data=$query->fetchAll();

 }


else{

	$query = $con->prepare("SELECT * FROM `places_table` WHERE `place_type` like '%%' and `place_name` like '%%' and `place_amount` like '%%'"); 
   $query->execute();
   $data=$query->fetchAll();
//var_dump($data);

}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Plan a trip</title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="footer, contact, form, icons" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Explore Bangladesh</title>

    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="ex_css/nav.css">
    <link href="https://fonts.googleapis.com/css?family=Julee" rel="stylesheet">
    
    <link href="https://fonts.googleapis.com/css?family=Architects+Daughter" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="ex_css/footer-distributed-with-contact-form.css">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/find_places.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->

</head>
<body>
	<?php require 'navbar.php'; ?>

	<div class="container">
	<div class="start">
		<div class="row">
			<div class="col-md-8">
			<?php
				 foreach($data as $result)
				{
   					 ?>
				<div class="place">
					<div class="row">
						<div class="col-md-6">
							<img src="img/<?php echo$result['place_pic_1']; ?>" class="img-rounded" alt="Cinque Terre" width="104%" height="36%">
						</div>

				
						<div class="col-md-6">
							Place: <?php echo$result['place_name']; ?><br>
							Type: <?php echo$result['place_type']; ?><br>
							Division: <?php  echo$result['place_div']; ?> <br><br>
							<i><?php echo$result['place_des_2']; ?></i><br><br>
							<button type="button" class="btn btn-info" onclick="window.location.href='description.php?id=<?php echo $result['place_id']; ?>'"> Details</button>

						</div>

					</div>
				</div>
				<?php } ?>
			</div>
						
			<div class="col-md-4">
				<div class="filter">
					<form method="POST" action="">
					  <div class="form-group">
					    <label for="formGroupExampleInput">Place Type</label>
						<select name="place_type[]" class="form-control" id="slct1"> 
						<option value="">All</option>
						<option value="Hill Track">Hill Track</option>
						<option value="Boat Trip">Boat Trip</option>
						<option value="Forest Traveling">Forest Traveling</option>
						<option value="Coastal Trip">Coastal Trip</option>
						<option value="Heritage Trip">Heritage Trip</option>

                        </select>
					  </div>

					  
					  <div class="form-group">
					    <label for="formGroupExampleInput2">Place Name</label>
					<select name="place_name[]" class="form-control" id="slct1">
					<option value="">All</option> 
						<option value="Nilachol">Nilachol</option>
						<option value="Ratargul">Ratargul</option>
						<option value="Bichanakandi">Bichanakandi</option>
						<option value="Sundarban">Sundarban</option>
						<option value="Saint Martin Island">Saint Martin Island</option>
						<option value="Heritage Places">Heritage Places</option>
                        
                        </select>
					  </div>
					  
					   <div class="form-group">
					    <label for="formGroupExampleInput2">Amount within</label>
					<select name="place_amount[]" class="form-control" id="slct1" > 
					<option value="">All</option>
					<option value="5000">5000</option>
					<option value="7000">7000</option>	
					<option value="10000">10000</option>
                        
                        </select>
					  </div>
					  
					  <div class="form-group">
					    <button type="submit" class="btn btn-success" input type="submit" name="submit"> Submit </button>
					  </div>
				</form>
				</div>

			</div>
		</div>
	</div>
	</div>
</body>
</html>