<footer class="footer-distributed">

      <div class="footer-left">

       <!--<img class="logo" src="img/explore_bd.jpg" alt="Explore Bangladesh">-->

        <p class="footer-links">
          <a href="#">Home</a>
          ·
          <a href="#">Blog</a>
          ·
          <a href="#">About</a>
          ·
          <a href="#">Faq</a>
          ·
          <a href="#">Contact</a>
        </p>

        <p class="footer-company-name">Explore Bangladesh &copy; 2017</p>
        <p class="footer-company-name">Mob: +8801983047867</p>
        <p class="footer-company-name">info@explorebd.com</p>


        <div class="footer-icons">

          <a href="#"><i class="fa fa-facebook"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          
          

        </div>

      </div>

      <div class="footer-right">

        <p>Contact Us</p>

        <form action="feedback.php" method="POST">

          <input type="" name="email" placeholder="Email" />
          <textarea name="message" placeholder="Message"></textarea>
          <button type="submit" class="btn btn-primary" input type="submit" name="send">Send</button>

        </form>

      </div>

    </footer>