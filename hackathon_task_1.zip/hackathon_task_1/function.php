<?php

	class USER
	{
	    public $db;
	 
	    function __construct($con)
	    {
	      $this->db = $con;
	    }

	 

	public function getPlace($id)
	{
		$select= $this->db->prepare("SELECT * FROM places_table WHERE place_id='$id'");
		$select->setFetchMode(PDO::FETCH_ASSOC);
		$select->execute();
			 
		$torres=$select->fetch();
		return $torres;
	}

	public function insert_message ($message,$email)
		{
			
			$st = $this->db->prepare("INSERT INTO message_table (message_body,message_user_email) VALUES (:message,:email)");
			$st->bindParam(':message',$message);
			$st->bindParam(':email',$email);

				
			$st->execute();

			$id=$this->db->lastInsertId();

			
				
			return $id;
			
			
		 			
			
		} 
		public function getUserName($name)
	{
		$select= $this->db->prepare("select user_name from user_info_table where user_name like :name");
		$select->execute(array(':name' => $name.'%'));			 
		$data=$select->fetchAll(PDO::FETCH_ASSOC);
		return $data;
	}

	public function getUserIdfromname($name)
	{
		$select= $this->db->prepare("SELECT user_id FROM user_info_table WHERE user_name='$name'");
		$select->setFetchMode(PDO::FETCH_ASSOC);
		$select->execute();
			 
		$torres=$select->fetch();
		return $torres;
	} 

	public function getUserId($id)
	{
		$select= $this->db->prepare("SELECT * FROM user_info_table WHERE user_id='$id'");
		$select->setFetchMode(PDO::FETCH_ASSOC);
		$select->execute();
			 
		$torres=$select->fetch();
		return $torres;
	}

	public function Event()
	{
		$qry = $this->db->prepare("SELECT * FROM event_table");
		$qry->execute();
	
		$row=$qry->fetchAll();
		return $row;
	}

	public function insert_multiple ($email, $password)
		{
			
			$st = $this->db->prepare("INSERT INTO user_info_table (user_email,user_password) VALUES (:email,:password)");
			$st->bindParam(':email',$email);
			$st->bindParam(':password',$password);

				
			$st->execute();

			$id=$this->db->lastInsertId();

			
				
			return $id;
			
			
		 			
			
		}

		public function search($user_hall,$user_batch,$user_country)
		{
			//$user_hall="Mir Mosharrof Hossain Hall";
			//$user_batch="44";
			//$user_country="Bangladesh";
			$select=$this->db->prepare("SELECT * FROM user_info_table WHERE user_hall=:user_hall AND user_batch=:user_batch AND user_country=:user_country");
			$select->bindParam(':user_batch',$user_batch);
			$select->bindParam(':user_hall',$user_hall);
			$select->bindParam(':user_country',$user_country);

			 $select->setFetchMode(PDO::FETCH_ASSOC);
			 $select->execute();
			 
			 $data=$select->fetchAll();
		}


	public function Login ($email, $password)
	{
		$select = $this->db->prepare("SELECT * FROM user_info_table WHERE user_email=:email and user_password=:password");
		$select->bindParam(':email', $email);
		$select->bindParam(':password', $password);
		$select->setFetchMode(PDO::FETCH_ASSOC);

		$select->execute();
		$data=$select->fetch();
		return $data;
	}

		public function admin_check ($id)
	{
		$select = $this->db->prepare("SELECT * FROM admin_table WHERE user_id=:id");
		$select->bindParam(':id', $id);
		
		$select->setFetchMode(PDO::FETCH_ASSOC);

		$select->execute();
		$data=$select->fetch();
		return $data;
	}	


	public function Edit($id,$full_name,$user_batch,$user_mobile_number,$user_birthdate,$user_present_address,$user_permanent_address,$user_bloodgroup,$user_occupation,$user_facebook_id,$user_linkedin_id,$user_sex,$user_marital_status,$user_country,$user_hall,$user_bio)
		{
			try
			{
				
				$select= $this->db->prepare("UPDATE user_info_table SET user_name=:full_name,user_batch=:user_batch,user_mobile_number=:user_mobile_number,user_birthdate=:user_birthdate,user_present_address=:user_present_address,user_permanent_address=:user_permanent_address,user_bloodgroup=:user_bloodgroup,user_occupation=:user_occupation,user_facebook_id=:user_facebook_id,user_linkedin_id=:user_linkedin_id,user_sex=:user_sex,user_marital_status=:user_marital_status,user_country=:user_country,user_hall=:user_hall,user_bio=:user_bio WHERE user_id=:id");
				$select->bindParam(':id',$id);
				$select->bindParam(':full_name',$full_name);
				$select->bindParam(':user_batch',$user_batch);
				$select->bindParam(':user_mobile_number',$user_mobile_number);
				$select->bindParam(':user_birthdate',$user_birthdate);
				$select->bindParam(':user_present_address',$user_present_address);
				$select->bindParam(':user_permanent_address',$user_permanent_address);
				$select->bindParam(':user_bloodgroup',$user_bloodgroup);
				$select->bindParam(':user_occupation',$user_occupation);
				$select->bindParam(':user_facebook_id',$user_facebook_id);
				$select->bindParam(':user_linkedin_id',$user_linkedin_id);
				$select->bindParam(':user_sex',$user_sex);
				$select->bindParam(':user_marital_status',$user_marital_status);
				$select->bindParam(':user_hall',$user_hall);
				$select->bindParam(':user_country',$user_country);
				$select->bindParam(':user_bio',$user_bio);

				
				

				$select->setFetchMode(PDO::FETCH_ASSOC);
				$select->execute();
				 
				$data=$select->fetchAll();
				
			}
			
			catch (PDOException $e)
			{
				echo $e->getMessage();
			}
		}

		public function EditPic($id,$user_pic)
		{
			$select= $this->db->prepare("UPDATE user_info_table SET user_picture1=:user_pic WHERE user_id=:id");
			$select->bindParam(":id",$id);
			$select->bindParam(":user_pic",$user_pic);
			$select->setFetchMode(PDO::FETCH_ASSOC);
			$select->execute();
				 
			


		}

		public function EditCoverPic($id,$user_pic)
		{
			$select= $this->db->prepare("UPDATE user_info_table SET user_picture2=:user_pic WHERE user_id=:id");
			$select->bindParam(":id",$id);
			$select->bindParam(":user_pic",$user_pic);
			$select->setFetchMode(PDO::FETCH_ASSOC);
			$select->execute();
				 
			


		}

		public function getAll()
		{
			
			$st = $this->db->prepare("SELECT * FROM user_info_table");
			$st->execute();
            //$ul=$st->fetch(PDO::FETCH_ASSOC);
            return $st;
			
		}


		public function delete_user($id)
		{
			try{
				$select = $this->db->prepare("DELETE FROM user_info_table WHERE user_id=:id");
				$select->bindParam(':id',$id);
				
				$select->execute();
				//header ("location:details.php");
				 
				
			}
			catch (PDOException $e)
			{
				echo $e->getMessage();
			}
		}
		public function delete_event($id)
		{
			try{
				$select = $this->db->prepare("DELETE FROM event_table WHERE id=:id");
				$select->bindParam(':id',$id);
				
				$select->execute();
				//header ("location:details.php");
				 
				
			}
			catch (PDOException $e)
			{
				echo $e->getMessage();
			}
		}
		public function get_event($id)
		{
			$select = $this->db->prepare("SELECT * FROM event_table WHERE id=:id");
			$select->bindParam(':id',$id);
			$select->execute();
			$data=$select->fetch();
			return $data;
		}
		public function update_event($event_title,$event_date,$event_time,$event_activity,$event_venue,$event_organizer,$event_type,$id)
		{

			$select = $this->db->prepare("UPDATE event_table SET event_title=:event_title,event_date=:event_date,event_time=:event_time,event_activity=:event_activity,event_venue=:event_vanue,event_organizer=:event_organizer,event_type=:event_type WHERE id=:id");


				$select->bindParam(':event_title',$event_title);
				$select->bindParam(':event_date',$event_date);
				$select->bindParam(':event_time',$event_time);
				$select->bindParam(':event_activity',$event_activity);
				$select->bindParam(':event_vanue',$event_vanue);
				$select->bindParam(':event_organizer',$event_organizer);
				$select->bindParam(':event_type',$event_type);
				$select->bindParam(':id',$id);

				$select->execute();



		}


		

}		
?>    