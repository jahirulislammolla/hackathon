<?php
require 'connection.php';

if (isset($_POST['send']))
{
	$email=$_POST['email'];
	$message=$_POST['message'];

	$fernando = $user->insert_message ($message,$email);
}

?>