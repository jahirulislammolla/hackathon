<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Image Upload</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="jpeg_camera/jpeg_camera_with_dependencies.min.js" type="text/javascript"></script>
	<script type="text/javascript"><!--

	    var options = {
	      shutter_ogg_url: "jpeg_camera/shutter.ogg",
	      shutter_mp3_url: "jpeg_camera/shutter.mp3",
	      swf_url: "jpeg_camera/jpeg_camera.swf",
	    };
	    var camera = new JpegCamera("#camera", options);
  
		$('#take_snapshots').click(function(){
		var snapshot = camera.capture();
		snapshot.show();
    
    	snapshot.upload({api_url: "action.php"}).done(function(response) {
		$('#imagelist').prepend("<tr><td><img src='"+response+"' width='100px' height='100px'></td><td>"+response+"</td></tr>");
		}).fail(function(response) {
 		 alert("Upload failed with status " + response);
		});
		})

function done(){
    $('#snapshots').html("uploaded");
}

// --></script>
</head>
<body>

	<div id="camera_info"></div>
    <div id="camera"></div><br>
    <button id="take_snapshots" class="btn btn-success btn-sm">Take Snapshots</button>


    <form>
 		<input type="button" value="Take Snapshot" onClick="take_snapshot()">
	</form>

	<table class="table table-bordered">
    <thead>
        <tr>
            <th>Image</th><th>Image Name</th>
        </tr>
    </thead>
    <tbody id="imagelist">
            
    </tbody>
</table>

</body>
</html>