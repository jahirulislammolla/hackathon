-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2017 at 12:59 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tourism_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `message_table`
--

CREATE TABLE `message_table` (
  `message_id` int(5) NOT NULL,
  `message_body` varchar(500) NOT NULL,
  `message_user_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message_table`
--

INSERT INTO `message_table` (`message_id`, `message_body`, `message_user_email`) VALUES
(1, 'Its really a great site. Its useful in many ways', 'shuvashishpaul64@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `places_table`
--

CREATE TABLE `places_table` (
  `place_id` int(3) NOT NULL,
  `place_name` varchar(20) NOT NULL,
  `place_div` varchar(20) NOT NULL,
  `place_type` varchar(30) NOT NULL,
  `place_amount` int(10) NOT NULL,
  `place_pic_1` varchar(100) NOT NULL,
  `place_pic_2` varchar(100) NOT NULL,
  `place_pic_3` varchar(100) NOT NULL,
  `place_pic_4` varchar(100) NOT NULL,
  `place_hotel_1` varchar(100) NOT NULL,
  `place_hotel_2` varchar(100) NOT NULL,
  `place_hotel_3` varchar(100) NOT NULL,
  `place_hotel_4` varchar(100) NOT NULL,
  `place_hotel_5` varchar(100) NOT NULL,
  `place_des_2` varchar(1000) NOT NULL,
  `place_des_3` varchar(1000) NOT NULL,
  `place_des_4` varchar(1000) NOT NULL,
  `place_youtube` varchar(100) NOT NULL,
  `place_lat` varchar(15) NOT NULL,
  `place_lng` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `places_table`
--

INSERT INTO `places_table` (`place_id`, `place_name`, `place_div`, `place_type`, `place_amount`, `place_pic_1`, `place_pic_2`, `place_pic_3`, `place_pic_4`, `place_hotel_1`, `place_hotel_2`, `place_hotel_3`, `place_hotel_4`, `place_hotel_5`, `place_des_2`, `place_des_3`, `place_des_4`, `place_youtube`, `place_lat`, `place_lng`) VALUES
(1, 'Nilachol', 'Chittagong', 'Hill Track', 5000, 'nil1.jpg', 'nilachol.jpg', 'n2.jpg', 'n1.jpg', 'Plaza', 'Green Land', 'Hill VIew', 'Hill Queen', 'HIllton', 'Nilachol is the nearest tourist spot from Bandarban which is called by many people "Dargiling of Bangla". The entire Bandarban city can be seen at a glance from Nilachol and a vast landscape.', 'When the sky is clear visitors can enjoy the attractive sight of Chittagong Port and Beach from Nilachol. Especially the sight of sunset at Nilachol brings us a feeling of heaven.', 'Visitors can be thrilled walking through the clouds in the rainy season.Visitors can observe an evergreen moonlight in the moonlit night. During the winter season, it is tremendous at the foggy morning. On the way to Nilachal, visitors can observe some tribe villages with their raw natural expression.', 'https://youtu.be/QcrmaKMwQ-c', '22.1668006', '92.2104001'),
(2, 'Ratargul', 'Sylhet', 'Boat Trip', 10000, 'rat1.jpg', 'rat2.jpg', 'rat3.jpg', 'rat4.jpg', 'Hotel Metro International', 'Hotel South City', 'Hotel Garden Inn', 'Hotel Supreme', 'Britannia Hotel', 'Ratargul Swamp Forest is a little Pantanal in Bangladesh. It is also called as Amazon of Bangladesh or Deshi Amazon or you can say Banglar Amazon. It is an evergreen and mystic forest as well as one of the best freshwater swamp forests in this world. It is located at the Goain Ghat area of Sylhet Division in Bangladesh. The beauty of this forest is bloomed mainly in the rainy season. The traveling taste of Ratargul is like to visit the Sundarbans but the water is not salty like Sundarban. It a fresh and clean water forest in the bank of Goain River and linked with the canal Chengir Khal. But the flow of the river is extreme during the rainy season.', 'It was raining lightly and the weather was extremely suitable for traveling. We are about 15 and everyone was very excited to visit the Banglar Amazon. We started a very comfortable journey from Dhaka by micro bus to save our valuable time and took many short breaks on the way to Sylhet. It is not necessary to take a private car or bus for this tour. You can use bus, train, and airways to reach Sylhet. On the way to Sylhet we also observed the historical Bhairab Bridge also known as Anderson Bridge, which is a 1 km long railway bridge over the Meghna River, connecting Bhairab Bazar Junction in Kishoreganj District with Ashuganj in Brahmanbaria District. The night view of Bhairab Bridge was awesome. ', 'Ratargul, locally this forest is called the Sundarbans of Bangladesh. There are only twenty-one more freshwater forests in the whole world! Ratargul is one of them. Various wild animals and birds live here and wander from branch to branch of trees. Rainy season and just after the rainy season (from July to October) is the suitable time to visit Ratargul.\r\nThe forest is about 26 kilometers from Sylhet city. It is situated at Guainghat upozila in Sylhet district under the Sylhet forest department in range-2. The total area of this wetland is about 30 thousand 3 hundred and 25 acres. In that wetland, Ratargul forest is in 5 hundred and 4 acres. During the rainy season, the forest goes under water of 20-30 feet and the water level is about 10 feet for rest of the year, but in winter it almost dries up. \r\n', 'https://www.youtube.com/embed/rQInTJmDjr8', '25.0140806', '91.922000'),
(3, 'Bichanakandi', 'Sylhet', 'Boat Trip', 7000, 'bic1.jpg', 'bic2.jpg', 'bic3.jpg', 'pan.jpg', 'Hotel Metro International', 'Hotel South City', 'Hotel Garden Inn', 'Hotel Supreme', 'Hotel Holy Gate', 'Bisanakandi is situated at Bangladesh-India border in Sylhet. It is a landscape beauty among gardens and hills. Bichanakandi is a village situated in Rustompur Union under Guainghat Upazilla. This is where many layers of the Khasi mountain meet at a single point from both sides. Flowing from above is a high fall. Adding to its charm are dark clouds hugging the mountain in the rainy season. And flowing underneath towards Bholaganj is a branch of the Piyain. Along the stream flowing from high up in the mountain come huge boulders that are deposited and mined in Bisanakandi.\r\nMuch like Jaflong, Bichnakandi is mostly a quarry. Winter is not a suitable time to visit Bisnakandi due to mechanized mining and stone-laden boats and lorries. The absence of such nuisance makes the rainy season the perfect time to visit the beautiful Bisanakandi that coalesces the charms of high mountains, sinuous rivers, graceful falls and dancing clouds.\r\n', 'It is located 25 kilometers North of Sylhet City in Gowainghat Upazila. There is more than one way to go to Bisnakandi. Tourists can use the Sylhet-Guainghat Road via the airport and take a left turn to reach Hadarpar from where a local boat may be hired to arrive at Bisnakandi. Visitors can go to Hadarpar by CNG-run auto-rickshaws, which are available for hire at Amberkhana Point in Sylhet city.\r\nAn alternative would be to go to Pangthumai first, and then hire a boat near Borhill Fall and ride along the branch of the Piyan which flows west towards Bisnakandi. The boat ride, which takes a little over an hour, on the sinuous river with lush green mountains on both sides is an unforgettable experience.\r\nIt is located 315 km away from Dhaka. Bisanakandi is 25 km away from Sylhet. You can take bus or CNG auto-rickshaw heading towards Sylhet-Gowainghat highway. At first you need to head to Sylhet from Dhaka.\r\n', 'It’s a small picturesque village, but the main attraction is the Boro Hill water fall. It’s one of the largest waterfall I have seen in my life, but also located in India. Boats can be hired from the base of the water fall for Bichakandi. May need to wait some time for a suitable one, as not that much available. Panthumai is one of the nice waterfall in sylhet. But the bad news is that this in not situated in Bangladesh. It is in the Indian territory. So Bangladeshi people have to enjoy far from the waterfall. But still that is awesome', 'https://www.youtube.com/embed/hhL2yCaS94U', '25.171482', ' 91.8820901'),
(4, 'Sundarban', 'Khulna', 'Forest Traveling', 10000, 'sun1.jpg', 'sun2.jpg', 'sun3.jpg', 'sun4.jpg', 'Richmond Hotel & Suites', 'Innotel Baton Rouge', 'Hotel 71', 'Tropical Daisy', 'Hotel Orchard Suites', 'The Sundarbans is a vast forest in the coastal region of the Bay of Bengal which is one of the natural wonders of the world. Located in the delta region of Padma, Meghna and Brahmaputra river basins, this unique forest area extends across South 24 Parganas and, North 24 Parganas districts of West Bengal State, India and Khulna, Satkhira, Bagerhat districts of Bangladesh.\r\n The Sundarbans is the largest forested forest in the world, as the largest mangrove forest in the coastal environment. Sunderbans, which has an area of 10000 sq.kms approx. out of which 6000 square kilometers, is in Bangladesh and around 4000 square kilometers is in West Bengal, India. In 1997, Sundarban was recognized as UNESCO World Heritage Site. The Bangladesh and Indian part of it is in fact an adjacent part of the uninterrupted landmark, but the list of UNESCO World Heritage List has been listed differently; In the name of "Sundarbans" and "Sundarban National Park" respectively.\r\n', 'The Sundarbans are trapped in the net, with small streams of marine streams, mud shores and mangrove forests, small-scale archipelago. 31.1 percent of the total forest area, which is 1,874 sq km, consists of riverbed, inlet, bill, and water.[1] Forests, known for its self-contained Royal Bengal Tiger, as well as numerous species of animals, including Chital Deer, Crocodile and Snakes . According to the survey, 500 tigers and 30,000 chitra deer are now in the Sunderban area. On 21 May 1992, Sundarban was recognized as a Ramsar Site.', 'The Sundarban forest lies in the vast delta on the Bay of Bengal formed by the super confluence of the Ganges, Hooghly, Padma, Brahmaputra and Meghna rivers across southern Bangladesh. The seasonally flooded Sundarbans freshwater swamp forests lie inland from the mangrove forests on the coastal fringe. The forest covers 10,000 square kilometres (3,900 sq mi) of which about 6,000 square kilometres (2,300 sq mi) are in Bangladesh. It became inscribed as a UNESCO world heritage site in 1997. The Indian part of Sundarbans is estimated to be about 4,110 square kilometres (1,590 sq mi), of which about 1,700 square kilometres (660 sq mi) is occupied by waterbodies in the forms of river, canals and creeks of width varying from a few metres to several kilometres.', 'https://www.youtube.com/embed/NgUYRwRb2Lo', '21.883371', '88.875173'),
(5, 'Saint Martin Island', 'Chittagong', 'Coastal Trip', 5000, 'sen1.jpg', 'sen2.jpg', 'sen3.jpg', 'sen4.jpg', 'Hotel Blue Sea', 'Blue Marine Resort', 'The Lagon Resort', 'Hotel Prince Heaven', 'Prasad Paradise', 'If you are done partying in Coxs Bazar, St. Martins Island is the right place to calm down your soul. This coral island is about 10km (6mi) south-west of the southern tip of the mainland is a tropical cliché, with beaches fringed with coconut palms and bountiful marine life. This island has the most amazing blue water. Far from the maddening crowd, the serenity in this island will help your meditate and purify your soul. This air is so fresh and soothing. And the water is clearer than crystal. During any moonlight in St. Island you may end up deciding to stay in this island forever. And sea-foods here are not only delicious, but also abundant in variation.\r\nThis amazing island is so small that it is possible to walk around the entire island. Each day a ferry leaves Teknaf for St. Martin’s Island which takes only 3 hours. You can hop in a Bus from Cox’s Bazar which will easily take you to St. Martin’s Island. And if you want to go directly from Dhaka, hop in a Dhaka-Teknaf Bus.\r\n', 'Teknafs Damdmia to Saint Martin every morning 10 oclock leave it ocean traffic utility ship. Of the specification are- ‘Keari Sindbad’, ‘LCT Kutubdia’, ‘Eagle’, ‘LCT Kajol’ etc. These ‘Teknaf-Saint Martin-Teknaf’ two way’s fare 600-1000 Taka. Time of low-tide main island are matching Chera Dwip but time of high-tide a little space tourist be crossing boat. Who do not reach walking there for Saint Martin wharf to Chera Dwip have engine boat and speedboat. Each per fare of engine boat 150-200 Taka and reserve speedboat fare 1200-1500 Taka.', 'Stay of Saint Martin as locations for the act good quality are hotel ‘Abokash porjoton Saint Martin resort. To Dhaka tourist can booking this two hotel. CTB Resorts Executive Double room fare are 2000/- Taka, Executive Triple room 2400/- Taka, Deluxe Double room 1600/- Taka, Two beds Tent 1000/- Taka. Contact – +880 1552 555 550, +880 1199 791 588. Saint Martin resort’s Executive room 2000/- Taka, Deluxe 1800/- Taka and different type of cottage fare are daily 1200-2000/- Taka. Contact – 8358485, +880 1552 420 602. It without Saint Martins different good quality are hotel – Blue Marine Resort, Preshad Paradise, Shimana Paria, Nil Dogonto Resort etc.', 'https://www.youtube.com/embed/kvld2Ik429A', '20.6207314', '92.3246388'),
(6, 'Heritage Places', 'others', 'Heritage Trip', 5000, 'shat.jpg', 'ahsan.jpg', 'kella.jpg', 'moha.jpg', 'Hotel Sonargaon', 'Ruposi Bangla Hotel', 'Dhaka Hotel', 'Hotel Naz Garden', 'The Sky Garden', 'Ahsan Manzil is one of the most significant architectural monuments of Bangladesh. The building structure was established on a raised platform of 1 meter, the two-storied palace measures 125.4m by 28.75m. The height of the ground floor is 5 meters and the height of the first floor is 5.8 meters. The thickness of the walls of the palace is about 0.78 meters. There are porticos of 5 meters height on the northern and southern sides of the palace. The building has a broad front-facing the Buriganga River. On the river side, an open spacious stairway leads right up to the second portal and on their stands the grand triple- arched portals. There was once a fountain in the garden in front of the stairs which does not exist today. All along the north and the south side of the building run spacious verandahs with an open terrace projected in the middle.', 'Lalbagh fort is a Mughal palace. It is one of the greatest heritage site of Dhaka, Bangladesh. It was built in 1678 A.D. by Muhammad Azam Shah and continued the work by his successor Nawab Shaista Khan. It has a huge area and many hidden passages. The fort has three important ancient buildings, Pari Bibir Mazar, Darbar Hall and a Mosque. Memorial of Pari Bibi was designed by marbles, two fount and different types of flora. Three domed Mosque shows the beauty of Mughal Architecture.Now there is a museum for the visitors to have the opportunity to see the ancient things used by the Nawab Shaista khan, paintings, furniture as well as weapons used in wars at Mughal period. Everyday many people come here to enjoy this beautiful and historical fort.', 'Mohasthangarh is one of the main attractions in north Bengal. It was the capital of Kingdom of the Mourjo, the Gupta and the Sen Dynasty.\r\nA visit to Mahasthangarh site museum will open up for you wide variety of antiquities, ranging from terracotta objects to gold ornaments and coins recovered from the site. Now it is one of the major tourist spots maintained by Bangladesh archeological Department.\r\nYou can go to Mohasthanagar from Bogra town, 10 km. away. Don’t forget to visit Mohasthangar museum while visiting Mohasthangar. Mohasthan Buddhist Stambho is another attraction for the tourists; it is locally called as Behula’s Basar.\r\n', 'https://www.youtube.com/embed/JTDOnYtYX6o', '24.9627991', '89.3457341');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `message_table`
--
ALTER TABLE `message_table`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `places_table`
--
ALTER TABLE `places_table`
  ADD PRIMARY KEY (`place_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `message_table`
--
ALTER TABLE `message_table`
  MODIFY `message_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `places_table`
--
ALTER TABLE `places_table`
  MODIFY `place_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
