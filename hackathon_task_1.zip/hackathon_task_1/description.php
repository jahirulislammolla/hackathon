<?php 
require 'connection.php';
$id=$_GET['id'];
$torres=$user->getPlace($id);
$lat=$torres['place_lat'];
$lng=$torres['place_lng'];
$title=$torres['place_name'];
//var_dump($torres);

?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="footer, contact, form, icons" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php echo $torres['place_name']; ?></title>

    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="ex_css/nav.css">
    <link href="https://fonts.googleapis.com/css?family=Julee" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="ex_css/gallery.css">
    <link rel="stylesheet" type="text/css" href="ex_css/des.css">
    <link href="https://fonts.googleapis.com/css?family=Architects+Daughter" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Anton" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="ex_css/footer-distributed-with-contact-form.css">
    <link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->

  
  </head>
  <body>
   <?php require 'navbar.php'; ?>
   <div class="container-fluid">
        <div class="head_image">
            <img src="img/<?php echo $torres['place_pic_1']; ?>" alt="Nilachol" title="<?php echo $torres['place_name']; ?>" id="wows1_0"/>
            <div class="caption"><p><?php echo $torres['place_type']; ?></p></div>
        </div>
<div class="main">
    <h1><?php echo $torres['place_name']; ?></h1>
</div>
<div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="" target="_blank">
          <img src="img/<?php echo $torres['place_pic_2']; ?>" alt="Lights" style="width:100%">
          </a>
          <div class="caption_image">
          <br>

            <p><?php echo $torres['place_des_2']; ?></p>
          </div>
        
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="/w3images/nature.jpg" target="_blank">
          <img src="img/<?php echo $torres['place_pic_3']; ?>" alt="Nature" style="width:100%">
        </a>
          <div class="caption_image">
          <br>
             <p><?php echo $torres['place_des_3']; ?></p>
          </div>
        
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="" target="_blank">
          <img src="img/<?php echo $torres['place_pic_4']; ?>" alt="Fjords" style="width:100%">
        </a>
          <div class="caption_image">
          <br>
             <p><?php echo $torres['place_des_4']; ?>.</p>
          </div>
        
      </div>
    </div>
  </div>


<div class="row">
    <div class="col-md-offset-1 col-md-4">
        
            <img class="accom_img" src="img/accom.jpg">
        <div class="hotel">
        <br>
        
            <a href="https://www.tripadvisor.com/Hotel_Review-s1-g2368232-d6363094-Reviews-Hotel_Plaza_Bandarban-Bandarban_Chittagong_Division.html" target="_blank"><p>Hotel <?php echo $torres['place_hotel_1']; ?></p></a>
            <a href="https://www.tripadvisor.com/Hotel_Review-s1-g2368232-d6363094-Reviews-Hotel_Plaza_Bandarban-Bandarban_Chittagong_Division.html" target="_blank"><p>Hotel <?php echo $torres['place_hotel_2']; ?></p></a>
            <a href="https://www.tripadvisor.com/Hotel_Review-s1-g2368232-d6363094-Reviews-Hotel_Plaza_Bandarban-Bandarban_Chittagong_Division.html" target="_blank"><p>Hotel <?php echo $torres['place_hotel_3']; ?></p></a>
            <a href="https://www.tripadvisor.com/Hotel_Review-s1-g2368232-d6363094-Reviews-Hotel_Plaza_Bandarban-Bandarban_Chittagong_Division.html" target="_blank"><p>Hotel <?php echo $torres['place_hotel_4']; ?></p></a>
            <a href="https://www.tripadvisor.com/Hotel_Review-s1-g2368232-d6363094-Reviews-Hotel_Plaza_Bandarban-Bandarban_Chittagong_Division.html" target="_blank"><p>Hotel <?php echo $torres['place_hotel_5']; ?></p></a>
            
        </div>
    </div>
    <div class="col-md-7">
        <div id="map" style="width:100%;height: 300px;"> </div>
    </div>
    
 </div> 

 <div class="col-md-offset-1 col-md-10 edit">
   <h3 class="image_heading"><b>Beautiful Nil Achol at a Glance</b></h3>
      <div class="embed-responsive embed-responsive-16by9 edit_video">
        <iframe class="embed-responsive-item"  src="<?php echo $torres['place_youtube'];?>"></iframe>
      </div>
  </div> 


<div class="row">
  <div class="col-sm-6">
    <h3>Comments</h3>
  </div>

  <!-- /col-sm-12 -->
</div><!-- /row -->
<div class="row">
<div class="col-sm-1">
<div class="thumbnail">
<img class="img-responsive user-photo" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">
</div><!-- /thumbnail -->
</div><!-- /col-sm-1 -->

<div class="col-sm-5">
<div class="panel panel-default">
<div class="panel-heading">
<form action="" method="POST">
<input type="text" name="" class="panel-heading edit_in" placeholder="username"><br><br>

<input type="textarea" name="" class="panel-body edit_in" placeholder="Comment"><br><br>
<button type="button" class="btn btn-secondary edit_button">Submit</button>

</form>
</div>
</div>
</div>
 <div class="col-sm-6 text-right">
        
            <img class="accom_img" src="img/tra.png">
            <div class="hotel">
            <br>
            <a href="https://www.shohoz.com/bus-tickets/Dhaka-to-Bandarban" target="_blank"><p>Sohoz.com</p></a>
            <a href="http://busbd.com.bd" target="_blank"><p>busbd.com.bd</p></a>
            <a href="" target="_blank"><p>Green Line</p></a>
            <a href="" target="_blank"><p>Shamoli</p></a>
            <a href="" target="_blank"><p>Train</p></a>
            
        </div>
    </div>
</div>

   </div>


   <?php require 'footer.php'; ?>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
     <script>
      var marker;
      var lat=parseFloat("<?php echo $lat;?>");
      var lng=parseFloat("<?php echo $lng;?>");
     
        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: {lat:lat, lng: lng}//24.9627991,89.3457341
        });

        marker = new google.maps.Marker({
          map: map,
          draggable: true,
          animation: google.maps.Animation.DROP,
          position: {lat: lat, lng: lng},
          title:"<?php echo $title;?>"
        });
        marker.addListener('click', toggleBounce);
      }

      function toggleBounce() {
        if (marker.getAnimation() !== null) {
          marker.setAnimation(null);
        } else {
          marker.setAnimation(google.maps.Animation.BOUNCE);
        }
      } 
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTIjeLm_jsh_kn3QmYUdf9YWbFJoljx-4&callback=initMap">

    </script>

  </body>
</html>