$(document).ready(function(){
    $("#myBtn").click(function(){
        $("#myModal").modal();
    });
});


$(function() {
  $('#js-news').ticker();
});
